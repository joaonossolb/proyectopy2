<?php
@session_start();
include("conexao.php");
include("funcoes.php");


if (isset($_POST['nome_empresaa']) and isset($_POST['tipo_empresa']) and isset($_POST['ruc']) and isset($_POST['cidade']) ) {
	//recebe inputs POST cadastra aluno
	$nome_empresaa = $_POST['nome_empresaa'];
	$tipo_empresa = $_POST['tipo_empresa'];
	$ruc = $_POST['ruc'];
	$cidade = $_POST['cidade'];
	


	//valida campos cadastra aluno
	$nome_empresaa_valida = valida_inputs(1, $nome_empresaa);
	$tipo_empresa_valida = valida_inputs(0, $tipo_empresa);
	$ruc_valida = valida_inputs(0, $ruc);
	$cidade_valida = valida_inputs(0, $cidade);
	
		//se todos os campos de validação for igual a 1, quer dizer que passou no regex e vai prosseguir com o cadastro
	if (
		$nome_empresaa_valida == 1 and
		$tipo_empresa_valida == 1 and
		$ruc_valida == 1 and
		$cidade_valida == 1
	) {
		//VERIFICA ID REPETIDO
		$sql_id_repetido = "SELECT pk_id FROM abm_empresa WHERE nome_empresa = '" . $nome_empresaa . "';";
		$query_id_repetido = mysqli_query($conn, $sql_id_repetido);
		$quantidade_id_repetido = mysqli_num_rows($query_id_repetido);

		//se o id nao for repetido, cadastra
		if ($quantidade_id_repetido == 0) {
		
		$sql_cadastra_abm_empresa = "INSERT INTO abm_empresa (nome_empresa, ruc) VALUES ('" . $nome_empresaa . "','" . $ruc . "')";
		mysqli_query($conn, $sql_cadastra_abm_empresa);
		
		$sql_max = "SELECT MAX(pk_id) FROM abm_empresa; ";
		$query_sql_max = mysqli_query($conn, $sql_max);
		$ver_sqlmax = mysqli_fetch_array($query_sql_max);
		$fk_id_empresa = $ver_sqlmax['MAX(pk_id)'];
		//$fk_id_empresa = $fk_id_empresa+1;
		$sql_cadastra_tabla_1 = "INSERT INTO tabla_1 (fk_id_tipo_empresa, fk_id_cidade, fk_id_empresa) VALUES ('" . $tipo_empresa . "','" . $cidade . "', '".$fk_id_empresa."')";
		
		
		
		mysqli_query($conn, $sql_cadastra_tabla_1);
		
		
		echo "<script> alert('empresa cadastrada com sucesso!');</script>";
		echo "<script>window.history.back();</script>";
		
		
		}//fim 		if ($quantidade_id_repetido == 0) {
			else{
				echo "<script> alert('empresa Já cadastrada!');</script>";
		echo "<script>window.history.back();</script>";
			}

	
}//fim if valida == 1
	}//fim if isset post