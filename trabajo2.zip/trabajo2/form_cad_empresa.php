<?php

@session_start();
include("conexao.php");
include("funcoes.php");

//querys

$sql_ver_tipo_empresa = "SELECT * FROM tipo_empresa ORDER BY pk_id DESC;";
//echo $sql;
$query_ver_tipo_empresa = mysqli_query($conn, $sql_ver_tipo_empresa);

$sql_ver_cidade = "SELECT * FROM cidade  ORDER BY pk_id DESC;";
//echo $sql;
$query_ver_cidade = mysqli_query($conn, $sql_ver_cidade);

   
    ?>
<label for="tipo_empresa"></label>
<table width="100%" border="1" align="center">
  <tr>
    <td><table width="100%" border="3">
  <tr>
    <td><form action="postss.php" method="POST">
                <label>Nome empresa</label><br>
                <input type="text" name="nome_empresaa"><br>
                <label>tipo empresa</label><br>
                
                <select name="tipo_empresa" id="select">
				<option value="0"></option>
				<?php
				 while ($ver_tipo_empresa = mysqli_fetch_array($query_ver_tipo_empresa)) {
					?>
					<option value="<?php echo $ver_tipo_empresa['pk_id'];?>"><?php echo $ver_tipo_empresa['nome_tipo_empresa'];?></option>
					<?php
	}//fim while ($ver_empresas = mysqli_fetch_array($query_ver_empresas)) {
				?>


</select><br>

                <label>RUC</label><br>
                <input type="text" name="ruc"><br>
                <label>cidade</label><br>
                
                <select name="cidade" id="select">
<option value="0"></option>
<?php
				 while ($ver_cidade = mysqli_fetch_array($query_ver_cidade)) {
					?>
					<option value="<?php echo $ver_cidade['pk_id'];?>"><?php echo $ver_cidade['nome_cidade'];?></option>
					<?php
	}//fim  while ($ver_cidade = mysqli_fetch_array($query_ver_cidade)) {
					
				?>
</select><br>

                <input type='submit' value='Enviar' >
            </form></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="3">
      <tr>
        <td><form id="form1" name="form1" method="post" action="">
          <p>PESQUISAR</p>
          <p>CIDADE:            </p>
          <p>
            <select name="cidade_pesquisar" id="cidade">
			<?php
			$query_ver_cidade = mysqli_query($conn, $sql_ver_cidade);
              while ($ver_cidade = mysqli_fetch_array($query_ver_cidade)) {
					?>
					<option value="<?php echo $ver_cidade['pk_id'];?>"><?php echo $ver_cidade['nome_cidade'];?></option>
					<?php
	}//fim  while ($ver_cidade = mysqli_fetch_array($query_ver_cidade)) {
					
				?>
            </select>
          </p>
          <p>RUC</p>
          <p>
  <input type="text" name="ruc_pesquisar" id="ruc_pesquisar" value="0"/>
          </p>
          <p>NOME EMPRESA</p>
          <p>
            <input type="text" name="nome_empresaa_pesquisar" id="nome_empresaa_pesquisar" value="0"/>
          </p>
          <p>
            <input type="submit" name="btn_pesquisar" id="button" value="Pesquisar" />
          </p>
        </form></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="100%" border="1">
      <tr>
        <td>NOME EMPRESA</td>
        <td>TIPO EMPRESA</td>
        <td>RUC</td>
        <td>CIDADE</td>
      </tr>
	  <?php
	  
	  if (isset($_POST['btn_pesquisar'])){
		  $cidade_pesquisar_valida = valida_inputs(1, $_POST['cidade_pesquisar']);
		  $nome_empresaa_pesquisar_valida = valida_inputs(1, $_POST['nome_empresaa_pesquisar']);
		  $ruc_pesquisar_valida = valida_inputs(1, $_POST['ruc_pesquisar']);
		  if ($cidade_pesquisar_valida == 1 and $nome_empresaa_pesquisar_valida ==1 and $ruc_pesquisar_valida == 1){
		  $sql_ver_cidade = "SELECT * FROM cidade  WHERE fk_id_cidade = '".$_POST['cidade_pesquisar']."' ;";
		  $query_ver_cidade = mysqli_query($conn, $sql_ver_cidade);
		 
			  
			  
			
			$sql_pesquisa_empresa = "SELECT * FROM abm_empresa WHERE nome_empresa LIKE '%" . $_POST['nome_empresaa_pesquisar'] . "%' or ruc LIKE '%" . $_POST['ruc_pesquisar'] . "%' ORDER BY pk_id DESC;";

		$query_pesquisa_empresa = mysqli_query($conn, $sql_pesquisa_empresa);
			 }//if ($cidade_pesquisar_valida == 1){
				 
				 
	  }//FIM IF ISSET POST btn_pesquisar
	  else{
		  
		  $sql_pesquisa_empresa = "SELECT * FROM abm_empresa ORDER BY pk_id DESC;";

		$query_pesquisa_empresa = mysqli_query($conn, $sql_pesquisa_empresa);
	  }
	  ?>
	  <?php
	  while ($ver_empresa = mysqli_fetch_array($query_pesquisa_empresa)) {
	  ?>
      <tr>
        <td><label for="nome_empresaa"></label>
          <input type="text" name="nome_empresaa" id="nome_empresaa" value="<?php echo $ver_empresa['nome_empresa'];?>"/></td>
        <td><label for="select2"></label>
          <select name="tipo_empresa" id="select2">
		  <?php
		  $sql_ver_tipo_empresa = "SELECT * FROM tabla_1 WHERE fk_id_empresa =" .$ver_empresa['pk_id']. ";";

		$query_ver_tipo_empresa = mysqli_query($conn, $sql_ver_tipo_empresa);
		$ver_id_tipo_empresa = mysqli_fetch_array($query_ver_tipo_empresa);
		$fk_id_tipo_empresa = $ver_id_tipo_empresa['fk_id_tipo_empresa'];
		$fk_id_cidade = $ver_id_tipo_empresa['fk_id_cidade'];
		  $sql_ver_tipo_empresa = "SELECT * FROM tipo_empresa WHERE pk_id =" .$fk_id_tipo_empresa. ";";

		$query_ver_tipo_empresa = mysqli_query($conn, $sql_ver_tipo_empresa);
		$ver_tipo_empresa = mysqli_fetch_array($query_ver_tipo_empresa);
		$tipo_empresa = $ver_tipo_empresa['nome_tipo_empresa'];
		
		  ?>
            <option><?php echo $tipo_empresa; ?></option>
            
          </select></td>
        <td><label for="ruc"></label>
          <input type="text" name="ruc" id="ruc" value="<?php echo $ver_empresa['ruc'];?>"/></td>
        <td><select name="cidade" id="tipo_empresa">
          <?php
		  
		  $sql_ver_cidade = "SELECT * FROM cidade WHERE pk_id =" .$fk_id_cidade . ";";

		$query_ver_cidade = mysqli_query($conn, $sql_ver_cidade);
		$ver_cidade = mysqli_fetch_array($query_ver_cidade);
		$cidade = $ver_cidade['nome_cidade'];
		
		  ?>
          <option><?php echo $cidade ;?></option>
        </select></td>
      </tr>
	  <?php
	  }//while ($ver_empresa = mysqli_fetch_array($query_pesquisa_empresa)) {
	  ?>
    </table></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>