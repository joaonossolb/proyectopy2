<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "vertrigo";
	$dbname = "trabajo2";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>